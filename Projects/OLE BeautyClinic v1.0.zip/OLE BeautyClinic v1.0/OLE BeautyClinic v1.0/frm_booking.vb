﻿Imports System.Data.SqlClient
Public Class frm_booking
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Dim Sitte As String

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub frm_booking_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ID AUTOMATIC READ
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select Id from Tbl_bookingform", connection)
        dr = command.ExecuteReader
        While dr.Read
            Txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()

        'DATA GRID VIEW
        command = New SqlCommand("select * from Tbl_bookingform", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        Dgv_booking.DataSource = ds.Tables(0)
        Dgv_booking.Refresh()



        If connection.State = ConnectionState.Closed Then
            connection.Open()

        End If
        command = New SqlCommand("select Items from Tbl_serviceregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            Cbo_ctry.Items.Add(dr.Item(0))

        End While
        dr.Close()
    End Sub

    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Dgv_booking_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_bookingform(Registerno,Name,Time,Date,Site,Place,Pincode,Categories)values('" + Txt_rgno.Text + "','" + Txt_name.Text + "','" + Txt_time.Text + "','" + dtp_date.Value + "','" + Sitte + "','" + Txt_place.Text + "','" + Txt_pin.Text + "','" + Cbo_ctry.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim book As New frm_booking
                Me.Hide()
                book.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
    End Sub

    Private Sub Rbtn_site_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Sitte = "Indoor"
    End Sub

    Private Sub Rbtn_sit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Sitte = "outdoor"
    End Sub


    Private Sub btn_save_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_bookingform(Registerno,Name,Time,Date,Site,Place,Pincode,Categories)values('" + Txt_rgno.Text + "','" + Txt_name.Text + "','" + Txt_time.Text + "','" + dtp_date.Value + "','" + Sitte + "','" + Txt_place.Text + "','" + Txt_pin.Text + "','" + Cbo_ctry.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim book As New frm_booking
                Me.Hide()
                book.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
    End Sub

    Private Sub Cmb_ctry_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Dgv_booking_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_booking.CellContentClick

    End Sub
End Class