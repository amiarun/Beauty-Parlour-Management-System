﻿Imports System.Data.SqlClient

Public Class frm_incomeregistration
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_close.Click, Button1.Click
        Me.Close()

    End Sub

    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_search.Click, Button2.Click
        Me.Width = 904
    End Sub

    Private Sub frm_incomeregistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'data grid veiw
        command = New SqlCommand("select*from Tbl_incomeregistration ", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        dgv_income.DataSource = ds.Tables(0)
        dgv_income.Refresh()
        'id
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select Id from Tbl_incomeregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()

    End Sub

   

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        'try code
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_incomeregistration(Date,Particular,Amount)values('" + dtp_date.Text + "','" + txt_particular.Text + "','" + txt_amount.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim income As New frm_incomeregistration
                Me.Hide()
                income.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
        'endof try code
    End Sub
End Class