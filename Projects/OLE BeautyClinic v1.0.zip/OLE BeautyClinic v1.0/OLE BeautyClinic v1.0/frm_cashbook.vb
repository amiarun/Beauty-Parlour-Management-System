﻿Imports System.Data.SqlClient
Public Class frm_cashbook
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub frm_cashbook_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ID AUTOMATIC READ
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select Id from Tbl_cashregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()

        'DATA GRID VIEW
        command = New SqlCommand("select * from  Tbl_cashregistration", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        Dgv_cashbook.DataSource = ds.Tables(0)
        Dgv_cashbook.Refresh()
    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'try code
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_cashregistration(Date,Type,amount,Particular)values('" + txt_particular.Text + "','" + txt_amount.Text + "','" + dtp_date.Value + "','" + cbo_type.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim cash As New frm_cashbook
                Me.Hide()
                cash.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
        'end of try code
    End Sub

   


   
    Private Sub btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class