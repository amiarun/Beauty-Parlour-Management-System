﻿Imports System.Data.SqlClient

Public Class frm_customer_Registration
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Txt_phno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_close.Click, Button2.Click
        Me.Close()


    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        'SAVE
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into tbl_customerregistration(Registrationno,name,DOB,housename,place,pincode,post,district,phoneno,category)values('" + txt_regno.Text + "','" + txt_name.Text + "','" + dtp_dob.Value + "','" + txt_hname.Text + "','" + Txt_post.Text + "','" + Txt_pin.Text + "','" + Txt_dis.Text + "','" + txt_district.Text + "','" + txt_phno.Text + "','" + Cmb_category.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim cust As New frm_customer_Registration
                Me.Hide()
                cust.Show()

            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()

       

    End Sub

    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_search.Click, Button1.Click

    End Sub

    Private Sub Btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_refresh.Click
        Dim cust As New frm_customer_Registration
        Me.Hide()
        cust.Show()
    End Sub

    Private Sub Lbl_searb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Lbl_searb.Click

    End Sub

    Private Sub Lbl_place_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Lbl_place.Click

    End Sub

    Private Sub Lbl_dob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Lbl_dob.Click

    End Sub

    Private Sub Lbl_name_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Lbl_name.Click

    End Sub

    Private Sub Dgv_customerregistration_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub frm_customer_Registration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ID AUTOMATIC READ
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select ID from tbl_customerregistration ", connection)
        dr = command.ExecuteReader
        While dr.Read
            txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()

        'DATA GRID VIEW
        command = New SqlCommand("select * from tbl_customerregistration", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        Dgv_customerregistration.DataSource = ds.Tables(0)
        Dgv_customerregistration.Refresh()

    End Sub
End Class