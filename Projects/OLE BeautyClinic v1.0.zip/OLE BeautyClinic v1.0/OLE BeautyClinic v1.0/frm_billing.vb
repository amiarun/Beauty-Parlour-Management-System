﻿Imports System.Data.SqlClient
Public Class frm_billing
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()

    End Sub

    Private Sub frm_billing_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'data grid veiw
        command = New SqlCommand("select*from Tbl_billingregistration ", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        Dgv_bill.DataSource = ds.Tables(0)
        Dgv_bill.Refresh()
        'id
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select Id from Tbl_billingregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            Txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()
    End Sub

    Private Sub Dgv_bill_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_bill.CellContentClick
        
    End Sub

    Private Sub Btn_close_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'try code
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_billingregistration(Registerno,Items,Totalrate,Discount,Phoneno)values('" + Txt_registerno.Text + "','" + cmb_item.Text + "','" + txt_total.Text + "','" + txt_discount.Text + "','" + txt_phone.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim bill As New frm_billing
                Me.Hide()
                bill.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
        'endof try code
    End Sub
    Private Sub Btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim bill As New frm_billing
        Me.Hide()
        bill.Show()
    End Sub

    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Txt_id_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Btn_go_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btn_update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_update.Click
        Dim i As Integer
        i = Dgv_bill.CurrentRow.Index
        Txt_id.Text = Dgv_bill.Item(0, i).Value
        Txt_registerno = Dgv_bill.Item(1, i).Value
        cmb_item = Dgv_bill.Item(2, i).Value
        txt_total = Dgv_bill.Item(3, i).Value
        txt_discount = Dgv_bill.Item(4, i).Value
        txt_phone = Dgv_bill.Item(1, i).Value
        btn_save.Text = "modify"
        Btn_search.Text = "Delete"
    End Sub
End Class