﻿Imports System.Data.SqlClient
Public Class frm_studentreport
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Btn_clo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_clo.Click
        Me.Close()

    End Sub

    Private Sub frm_studentreport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        

    End Sub

    Private Sub Btn_refres_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_refres.Click
        Dim studrep As New frm_staffreport
        Me.Hide()
        studrep.Show()
    End Sub

    Private Sub Dgv_student_report_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_student_report.CellContentClick
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim studentprint As New frm_studentprint
        studentprint.show()

    End Sub
End Class