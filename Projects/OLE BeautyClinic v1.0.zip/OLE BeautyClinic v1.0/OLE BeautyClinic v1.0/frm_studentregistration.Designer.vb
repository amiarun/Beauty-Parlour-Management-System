﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_studentregistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Dtp_da = New System.Windows.Forms.DateTimePicker
        Me.Dtp_date = New System.Windows.Forms.DateTimePicker
        Me.Lbl_c = New System.Windows.Forms.Label
        Me.Lbl_co = New System.Windows.Forms.Label
        Me.Lbl_e = New System.Windows.Forms.Label
        Me.Lbl_i = New System.Windows.Forms.Label
        Me.Lbl_m = New System.Windows.Forms.Label
        Me.Lbl_g = New System.Windows.Forms.Label
        Me.Lbl_r = New System.Windows.Forms.Label
        Me.Lbl_gph = New System.Windows.Forms.Label
        Me.Lbl_so = New System.Windows.Forms.Label
        Me.Btn_browse = New System.Windows.Forms.Button
        Me.Lbl_smco = New System.Windows.Forms.Label
        Me.pb_stud = New System.Windows.Forms.PictureBox
        Me.Lbl_colom = New System.Windows.Forms.Label
        Me.Txt_dis = New System.Windows.Forms.TextBox
        Me.Lbl_me = New System.Windows.Forms.Label
        Me.Lbl_dis = New System.Windows.Forms.Label
        Me.Lbl_sa = New System.Windows.Forms.Label
        Me.Txt_phno = New System.Windows.Forms.TextBox
        Me.Lbl_mo = New System.Windows.Forms.Label
        Me.Lbl_phno = New System.Windows.Forms.Label
        Me.Lbl_mi = New System.Windows.Forms.Label
        Me.Lbl_se = New System.Windows.Forms.Label
        Me.Lbl_dob = New System.Windows.Forms.Label
        Me.Lbl_s = New System.Windows.Forms.Label
        Me.Txt_oname = New System.Windows.Forms.TextBox
        Me.Lbl_semi = New System.Windows.Forms.Label
        Me.Lbl_oname = New System.Windows.Forms.Label
        Me.Txt_gname = New System.Windows.Forms.TextBox
        Me.Lbl_gname = New System.Windows.Forms.Label
        Me.Txt_relation = New System.Windows.Forms.TextBox
        Me.Lbl_rela = New System.Windows.Forms.Label
        Me.txt_gphno = New System.Windows.Forms.TextBox
        Me.Lbl_gphno = New System.Windows.Forms.Label
        Me.Txt_pin = New System.Windows.Forms.TextBox
        Me.Lbl_pinc = New System.Windows.Forms.Label
        Me.Txt_post = New System.Windows.Forms.TextBox
        Me.Lbl_post = New System.Windows.Forms.Label
        Me.Txt_place = New System.Windows.Forms.TextBox
        Me.Lbl_place = New System.Windows.Forms.Label
        Me.Txt_name = New System.Windows.Forms.TextBox
        Me.Lbl_name = New System.Windows.Forms.Label
        Me.Lbl_sdate = New System.Windows.Forms.Label
        Me.Txt_timming = New System.Windows.Forms.TextBox
        Me.Lbl_tmg = New System.Windows.Forms.Label
        Me.Txt_dur = New System.Windows.Forms.TextBox
        Me.Lbl_duration = New System.Windows.Forms.Label
        Me.Txt_fee = New System.Windows.Forms.TextBox
        Me.Lbl_fees = New System.Windows.Forms.Label
        Me.Txt_course = New System.Windows.Forms.TextBox
        Me.Lbl_course = New System.Windows.Forms.Label
        Me.Txt_rgno = New System.Windows.Forms.TextBox
        Me.Lbl_rgno = New System.Windows.Forms.Label
        Me.Txt_id = New System.Windows.Forms.TextBox
        Me.Lbl_id = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lbl_sco = New System.Windows.Forms.Label
        Me.Btn_go = New System.Windows.Forms.Button
        Me.Cmb_sby = New System.Windows.Forms.ComboBox
        Me.Txt_sdata = New System.Windows.Forms.TextBox
        Me.Lbl_sdata = New System.Windows.Forms.Label
        Me.Lbl_sby = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Dgv_student_registration = New System.Windows.Forms.DataGridView
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btn_save = New System.Windows.Forms.Button
        Me.Btn_close = New System.Windows.Forms.Button
        Me.Btn_refresh = New System.Windows.Forms.Button
        Me.Btn_search = New System.Windows.Forms.Button
        CType(Me.pb_stud, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.Dgv_student_registration, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Dtp_da
        '
        Me.Dtp_da.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_da.Location = New System.Drawing.Point(203, 379)
        Me.Dtp_da.Name = "Dtp_da"
        Me.Dtp_da.Size = New System.Drawing.Size(159, 23)
        Me.Dtp_da.TabIndex = 118
        '
        'Dtp_date
        '
        Me.Dtp_date.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_date.Location = New System.Drawing.Point(203, 183)
        Me.Dtp_date.Name = "Dtp_date"
        Me.Dtp_date.Size = New System.Drawing.Size(159, 23)
        Me.Dtp_date.TabIndex = 117
        '
        'Lbl_c
        '
        Me.Lbl_c.AutoSize = True
        Me.Lbl_c.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_c.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_c.Location = New System.Drawing.Point(174, 296)
        Me.Lbl_c.Name = "Lbl_c"
        Me.Lbl_c.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_c.TabIndex = 116
        Me.Lbl_c.Text = ":"
        '
        'Lbl_co
        '
        Me.Lbl_co.AutoSize = True
        Me.Lbl_co.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_co.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_co.Location = New System.Drawing.Point(174, 324)
        Me.Lbl_co.Name = "Lbl_co"
        Me.Lbl_co.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_co.TabIndex = 115
        Me.Lbl_co.Text = ":"
        '
        'Lbl_e
        '
        Me.Lbl_e.AutoSize = True
        Me.Lbl_e.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_e.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_e.Location = New System.Drawing.Point(174, 352)
        Me.Lbl_e.Name = "Lbl_e"
        Me.Lbl_e.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_e.TabIndex = 114
        Me.Lbl_e.Text = ":"
        '
        'Lbl_i
        '
        Me.Lbl_i.AutoSize = True
        Me.Lbl_i.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_i.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_i.Location = New System.Drawing.Point(175, 380)
        Me.Lbl_i.Name = "Lbl_i"
        Me.Lbl_i.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_i.TabIndex = 113
        Me.Lbl_i.Text = ":"
        '
        'Lbl_m
        '
        Me.Lbl_m.AutoSize = True
        Me.Lbl_m.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_m.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_m.Location = New System.Drawing.Point(175, 408)
        Me.Lbl_m.Name = "Lbl_m"
        Me.Lbl_m.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_m.TabIndex = 112
        Me.Lbl_m.Text = ":"
        '
        'Lbl_g
        '
        Me.Lbl_g.AutoSize = True
        Me.Lbl_g.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_g.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_g.Location = New System.Drawing.Point(173, 436)
        Me.Lbl_g.Name = "Lbl_g"
        Me.Lbl_g.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_g.TabIndex = 111
        Me.Lbl_g.Text = ":"
        '
        'Lbl_r
        '
        Me.Lbl_r.AutoSize = True
        Me.Lbl_r.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_r.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_r.Location = New System.Drawing.Point(175, 464)
        Me.Lbl_r.Name = "Lbl_r"
        Me.Lbl_r.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_r.TabIndex = 110
        Me.Lbl_r.Text = ":"
        '
        'Lbl_gph
        '
        Me.Lbl_gph.AutoSize = True
        Me.Lbl_gph.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_gph.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_gph.Location = New System.Drawing.Point(175, 492)
        Me.Lbl_gph.Name = "Lbl_gph"
        Me.Lbl_gph.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_gph.TabIndex = 109
        Me.Lbl_gph.Text = ":"
        '
        'Lbl_so
        '
        Me.Lbl_so.AutoSize = True
        Me.Lbl_so.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_so.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_so.Location = New System.Drawing.Point(173, 240)
        Me.Lbl_so.Name = "Lbl_so"
        Me.Lbl_so.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_so.TabIndex = 108
        Me.Lbl_so.Text = ":"
        '
        'Btn_browse
        '
        Me.Btn_browse.BackColor = System.Drawing.Color.Transparent
        Me.Btn_browse.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_browse.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_browse.Location = New System.Drawing.Point(425, 149)
        Me.Btn_browse.Name = "Btn_browse"
        Me.Btn_browse.Size = New System.Drawing.Size(127, 39)
        Me.Btn_browse.TabIndex = 98
        Me.Btn_browse.Text = "Browse"
        Me.Btn_browse.UseVisualStyleBackColor = False
        '
        'Lbl_smco
        '
        Me.Lbl_smco.AutoSize = True
        Me.Lbl_smco.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_smco.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_smco.Location = New System.Drawing.Point(173, 268)
        Me.Lbl_smco.Name = "Lbl_smco"
        Me.Lbl_smco.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_smco.TabIndex = 107
        Me.Lbl_smco.Text = ":"
        '
        'pb_stud
        '
        Me.pb_stud.BackColor = System.Drawing.Color.Transparent
        Me.pb_stud.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pb_stud.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pb_stud.Location = New System.Drawing.Point(417, 15)
        Me.pb_stud.Name = "pb_stud"
        Me.pb_stud.Size = New System.Drawing.Size(151, 128)
        Me.pb_stud.TabIndex = 97
        Me.pb_stud.TabStop = False
        '
        'Lbl_colom
        '
        Me.Lbl_colom.AutoSize = True
        Me.Lbl_colom.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_colom.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_colom.Location = New System.Drawing.Point(173, 128)
        Me.Lbl_colom.Name = "Lbl_colom"
        Me.Lbl_colom.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_colom.TabIndex = 106
        Me.Lbl_colom.Text = ":"
        '
        'Txt_dis
        '
        Me.Txt_dis.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_dis.Location = New System.Drawing.Point(202, 323)
        Me.Txt_dis.Name = "Txt_dis"
        Me.Txt_dis.Size = New System.Drawing.Size(160, 23)
        Me.Txt_dis.TabIndex = 96
        '
        'Lbl_me
        '
        Me.Lbl_me.AutoSize = True
        Me.Lbl_me.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_me.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_me.Location = New System.Drawing.Point(173, 212)
        Me.Lbl_me.Name = "Lbl_me"
        Me.Lbl_me.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_me.TabIndex = 105
        Me.Lbl_me.Text = ":"
        '
        'Lbl_dis
        '
        Me.Lbl_dis.AutoSize = True
        Me.Lbl_dis.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_dis.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_dis.Location = New System.Drawing.Point(17, 329)
        Me.Lbl_dis.Name = "Lbl_dis"
        Me.Lbl_dis.Size = New System.Drawing.Size(51, 17)
        Me.Lbl_dis.TabIndex = 95
        Me.Lbl_dis.Text = "District"
        '
        'Lbl_sa
        '
        Me.Lbl_sa.AutoSize = True
        Me.Lbl_sa.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_sa.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_sa.Location = New System.Drawing.Point(173, 184)
        Me.Lbl_sa.Name = "Lbl_sa"
        Me.Lbl_sa.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_sa.TabIndex = 104
        Me.Lbl_sa.Text = ":"
        '
        'Txt_phno
        '
        Me.Txt_phno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_phno.Location = New System.Drawing.Point(202, 351)
        Me.Txt_phno.Name = "Txt_phno"
        Me.Txt_phno.Size = New System.Drawing.Size(160, 23)
        Me.Txt_phno.TabIndex = 94
        '
        'Lbl_mo
        '
        Me.Lbl_mo.AutoSize = True
        Me.Lbl_mo.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_mo.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_mo.Location = New System.Drawing.Point(173, 156)
        Me.Lbl_mo.Name = "Lbl_mo"
        Me.Lbl_mo.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_mo.TabIndex = 103
        Me.Lbl_mo.Text = ":"
        '
        'Lbl_phno
        '
        Me.Lbl_phno.AutoSize = True
        Me.Lbl_phno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_phno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_phno.Location = New System.Drawing.Point(17, 357)
        Me.Lbl_phno.Name = "Lbl_phno"
        Me.Lbl_phno.Size = New System.Drawing.Size(71, 17)
        Me.Lbl_phno.TabIndex = 93
        Me.Lbl_phno.Text = "phone no"
        '
        'Lbl_mi
        '
        Me.Lbl_mi.AutoSize = True
        Me.Lbl_mi.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_mi.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_mi.Location = New System.Drawing.Point(173, 16)
        Me.Lbl_mi.Name = "Lbl_mi"
        Me.Lbl_mi.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_mi.TabIndex = 102
        Me.Lbl_mi.Text = ":"
        '
        'Lbl_se
        '
        Me.Lbl_se.AutoSize = True
        Me.Lbl_se.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_se.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_se.Location = New System.Drawing.Point(173, 100)
        Me.Lbl_se.Name = "Lbl_se"
        Me.Lbl_se.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_se.TabIndex = 101
        Me.Lbl_se.Text = ":"
        '
        'Lbl_dob
        '
        Me.Lbl_dob.AutoSize = True
        Me.Lbl_dob.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_dob.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_dob.Location = New System.Drawing.Point(18, 385)
        Me.Lbl_dob.Name = "Lbl_dob"
        Me.Lbl_dob.Size = New System.Drawing.Size(36, 17)
        Me.Lbl_dob.TabIndex = 92
        Me.Lbl_dob.Text = "DOB"
        '
        'Lbl_s
        '
        Me.Lbl_s.AutoSize = True
        Me.Lbl_s.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_s.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_s.Location = New System.Drawing.Point(173, 72)
        Me.Lbl_s.Name = "Lbl_s"
        Me.Lbl_s.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_s.TabIndex = 100
        Me.Lbl_s.Text = ":"
        '
        'Txt_oname
        '
        Me.Txt_oname.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_oname.Location = New System.Drawing.Point(201, 407)
        Me.Txt_oname.Name = "Txt_oname"
        Me.Txt_oname.Size = New System.Drawing.Size(160, 23)
        Me.Txt_oname.TabIndex = 91
        '
        'Lbl_semi
        '
        Me.Lbl_semi.AutoSize = True
        Me.Lbl_semi.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_semi.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_semi.Location = New System.Drawing.Point(173, 44)
        Me.Lbl_semi.Name = "Lbl_semi"
        Me.Lbl_semi.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_semi.TabIndex = 99
        Me.Lbl_semi.Text = ":"
        '
        'Lbl_oname
        '
        Me.Lbl_oname.AutoSize = True
        Me.Lbl_oname.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_oname.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_oname.Location = New System.Drawing.Point(16, 413)
        Me.Lbl_oname.Name = "Lbl_oname"
        Me.Lbl_oname.Size = New System.Drawing.Size(88, 17)
        Me.Lbl_oname.TabIndex = 90
        Me.Lbl_oname.Text = "Office name"
        '
        'Txt_gname
        '
        Me.Txt_gname.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_gname.Location = New System.Drawing.Point(201, 435)
        Me.Txt_gname.Name = "Txt_gname"
        Me.Txt_gname.Size = New System.Drawing.Size(160, 23)
        Me.Txt_gname.TabIndex = 89
        '
        'Lbl_gname
        '
        Me.Lbl_gname.AutoSize = True
        Me.Lbl_gname.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_gname.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_gname.Location = New System.Drawing.Point(16, 441)
        Me.Lbl_gname.Name = "Lbl_gname"
        Me.Lbl_gname.Size = New System.Drawing.Size(111, 17)
        Me.Lbl_gname.TabIndex = 88
        Me.Lbl_gname.Text = "Guardian name"
        '
        'Txt_relation
        '
        Me.Txt_relation.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_relation.Location = New System.Drawing.Point(201, 463)
        Me.Txt_relation.Name = "Txt_relation"
        Me.Txt_relation.Size = New System.Drawing.Size(160, 23)
        Me.Txt_relation.TabIndex = 87
        '
        'Lbl_rela
        '
        Me.Lbl_rela.AutoSize = True
        Me.Lbl_rela.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_rela.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_rela.Location = New System.Drawing.Point(16, 469)
        Me.Lbl_rela.Name = "Lbl_rela"
        Me.Lbl_rela.Size = New System.Drawing.Size(61, 17)
        Me.Lbl_rela.TabIndex = 86
        Me.Lbl_rela.Text = "Relation"
        '
        'txt_gphno
        '
        Me.txt_gphno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_gphno.Location = New System.Drawing.Point(201, 491)
        Me.txt_gphno.Name = "txt_gphno"
        Me.txt_gphno.Size = New System.Drawing.Size(160, 23)
        Me.txt_gphno.TabIndex = 85
        '
        'Lbl_gphno
        '
        Me.Lbl_gphno.AutoSize = True
        Me.Lbl_gphno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_gphno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_gphno.Location = New System.Drawing.Point(16, 497)
        Me.Lbl_gphno.Name = "Lbl_gphno"
        Me.Lbl_gphno.Size = New System.Drawing.Size(136, 17)
        Me.Lbl_gphno.TabIndex = 84
        Me.Lbl_gphno.Text = "Guardian phone no"
        '
        'Txt_pin
        '
        Me.Txt_pin.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_pin.Location = New System.Drawing.Point(202, 295)
        Me.Txt_pin.Name = "Txt_pin"
        Me.Txt_pin.Size = New System.Drawing.Size(160, 23)
        Me.Txt_pin.TabIndex = 83
        '
        'Lbl_pinc
        '
        Me.Lbl_pinc.AutoSize = True
        Me.Lbl_pinc.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_pinc.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_pinc.Location = New System.Drawing.Point(17, 301)
        Me.Lbl_pinc.Name = "Lbl_pinc"
        Me.Lbl_pinc.Size = New System.Drawing.Size(61, 17)
        Me.Lbl_pinc.TabIndex = 82
        Me.Lbl_pinc.Text = "Pincode"
        '
        'Txt_post
        '
        Me.Txt_post.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_post.Location = New System.Drawing.Point(202, 267)
        Me.Txt_post.Name = "Txt_post"
        Me.Txt_post.Size = New System.Drawing.Size(160, 23)
        Me.Txt_post.TabIndex = 81
        '
        'Lbl_post
        '
        Me.Lbl_post.AutoSize = True
        Me.Lbl_post.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_post.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_post.Location = New System.Drawing.Point(17, 273)
        Me.Lbl_post.Name = "Lbl_post"
        Me.Lbl_post.Size = New System.Drawing.Size(35, 17)
        Me.Lbl_post.TabIndex = 80
        Me.Lbl_post.Text = "Post"
        '
        'Txt_place
        '
        Me.Txt_place.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_place.Location = New System.Drawing.Point(202, 239)
        Me.Txt_place.Name = "Txt_place"
        Me.Txt_place.Size = New System.Drawing.Size(160, 23)
        Me.Txt_place.TabIndex = 79
        '
        'Lbl_place
        '
        Me.Lbl_place.AutoSize = True
        Me.Lbl_place.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_place.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_place.Location = New System.Drawing.Point(17, 245)
        Me.Lbl_place.Name = "Lbl_place"
        Me.Lbl_place.Size = New System.Drawing.Size(44, 17)
        Me.Lbl_place.TabIndex = 78
        Me.Lbl_place.Text = "Place"
        '
        'Txt_name
        '
        Me.Txt_name.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_name.Location = New System.Drawing.Point(202, 211)
        Me.Txt_name.Name = "Txt_name"
        Me.Txt_name.Size = New System.Drawing.Size(160, 23)
        Me.Txt_name.TabIndex = 77
        '
        'Lbl_name
        '
        Me.Lbl_name.AutoSize = True
        Me.Lbl_name.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_name.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_name.Location = New System.Drawing.Point(17, 217)
        Me.Lbl_name.Name = "Lbl_name"
        Me.Lbl_name.Size = New System.Drawing.Size(48, 17)
        Me.Lbl_name.TabIndex = 76
        Me.Lbl_name.Text = "Name"
        '
        'Lbl_sdate
        '
        Me.Lbl_sdate.AutoSize = True
        Me.Lbl_sdate.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_sdate.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_sdate.Location = New System.Drawing.Point(17, 189)
        Me.Lbl_sdate.Name = "Lbl_sdate"
        Me.Lbl_sdate.Size = New System.Drawing.Size(92, 17)
        Me.Lbl_sdate.TabIndex = 75
        Me.Lbl_sdate.Text = "Starting date"
        '
        'Txt_timming
        '
        Me.Txt_timming.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_timming.Location = New System.Drawing.Point(202, 155)
        Me.Txt_timming.Name = "Txt_timming"
        Me.Txt_timming.Size = New System.Drawing.Size(160, 23)
        Me.Txt_timming.TabIndex = 74
        '
        'Lbl_tmg
        '
        Me.Lbl_tmg.AutoSize = True
        Me.Lbl_tmg.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_tmg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_tmg.Location = New System.Drawing.Point(17, 161)
        Me.Lbl_tmg.Name = "Lbl_tmg"
        Me.Lbl_tmg.Size = New System.Drawing.Size(62, 17)
        Me.Lbl_tmg.TabIndex = 73
        Me.Lbl_tmg.Text = "Timming"
        '
        'Txt_dur
        '
        Me.Txt_dur.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_dur.Location = New System.Drawing.Point(202, 127)
        Me.Txt_dur.Name = "Txt_dur"
        Me.Txt_dur.Size = New System.Drawing.Size(160, 23)
        Me.Txt_dur.TabIndex = 72
        '
        'Lbl_duration
        '
        Me.Lbl_duration.AutoSize = True
        Me.Lbl_duration.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_duration.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_duration.Location = New System.Drawing.Point(17, 133)
        Me.Lbl_duration.Name = "Lbl_duration"
        Me.Lbl_duration.Size = New System.Drawing.Size(64, 17)
        Me.Lbl_duration.TabIndex = 71
        Me.Lbl_duration.Text = "Duration"
        '
        'Txt_fee
        '
        Me.Txt_fee.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_fee.Location = New System.Drawing.Point(202, 99)
        Me.Txt_fee.Name = "Txt_fee"
        Me.Txt_fee.Size = New System.Drawing.Size(160, 23)
        Me.Txt_fee.TabIndex = 70
        '
        'Lbl_fees
        '
        Me.Lbl_fees.AutoSize = True
        Me.Lbl_fees.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_fees.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_fees.Location = New System.Drawing.Point(17, 105)
        Me.Lbl_fees.Name = "Lbl_fees"
        Me.Lbl_fees.Size = New System.Drawing.Size(35, 17)
        Me.Lbl_fees.TabIndex = 69
        Me.Lbl_fees.Text = "Fees"
        '
        'Txt_course
        '
        Me.Txt_course.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_course.Location = New System.Drawing.Point(202, 71)
        Me.Txt_course.Name = "Txt_course"
        Me.Txt_course.Size = New System.Drawing.Size(160, 23)
        Me.Txt_course.TabIndex = 68
        '
        'Lbl_course
        '
        Me.Lbl_course.AutoSize = True
        Me.Lbl_course.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_course.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_course.Location = New System.Drawing.Point(17, 77)
        Me.Lbl_course.Name = "Lbl_course"
        Me.Lbl_course.Size = New System.Drawing.Size(53, 17)
        Me.Lbl_course.TabIndex = 67
        Me.Lbl_course.Text = "Course"
        '
        'Txt_rgno
        '
        Me.Txt_rgno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_rgno.Location = New System.Drawing.Point(202, 43)
        Me.Txt_rgno.Name = "Txt_rgno"
        Me.Txt_rgno.Size = New System.Drawing.Size(160, 23)
        Me.Txt_rgno.TabIndex = 66
        '
        'Lbl_rgno
        '
        Me.Lbl_rgno.AutoSize = True
        Me.Lbl_rgno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_rgno.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_rgno.Location = New System.Drawing.Point(17, 49)
        Me.Lbl_rgno.Name = "Lbl_rgno"
        Me.Lbl_rgno.Size = New System.Drawing.Size(105, 17)
        Me.Lbl_rgno.TabIndex = 65
        Me.Lbl_rgno.Text = "Registration no"
        '
        'Txt_id
        '
        Me.Txt_id.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_id.Location = New System.Drawing.Point(202, 15)
        Me.Txt_id.Name = "Txt_id"
        Me.Txt_id.Size = New System.Drawing.Size(160, 23)
        Me.Txt_id.TabIndex = 64
        '
        'Lbl_id
        '
        Me.Lbl_id.AutoSize = True
        Me.Lbl_id.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_id.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_id.Location = New System.Drawing.Point(17, 21)
        Me.Lbl_id.Name = "Lbl_id"
        Me.Lbl_id.Size = New System.Drawing.Size(21, 17)
        Me.Lbl_id.TabIndex = 63
        Me.Lbl_id.Text = "ID"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Lbl_sco)
        Me.GroupBox1.Controls.Add(Me.Btn_go)
        Me.GroupBox1.Controls.Add(Me.Cmb_sby)
        Me.GroupBox1.Controls.Add(Me.Txt_sdata)
        Me.GroupBox1.Controls.Add(Me.Lbl_sdata)
        Me.GroupBox1.Controls.Add(Me.Lbl_sby)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 523)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(676, 64)
        Me.GroupBox1.TabIndex = 119
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(407, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(12, 17)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = ":"
        '
        'Lbl_sco
        '
        Me.Lbl_sco.AutoSize = True
        Me.Lbl_sco.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_sco.Location = New System.Drawing.Point(73, 32)
        Me.Lbl_sco.Name = "Lbl_sco"
        Me.Lbl_sco.Size = New System.Drawing.Size(12, 17)
        Me.Lbl_sco.TabIndex = 52
        Me.Lbl_sco.Text = ":"
        '
        'Btn_go
        '
        Me.Btn_go.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_go.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_go.Location = New System.Drawing.Point(584, 17)
        Me.Btn_go.Name = "Btn_go"
        Me.Btn_go.Size = New System.Drawing.Size(76, 41)
        Me.Btn_go.TabIndex = 50
        Me.Btn_go.Text = "GO"
        Me.Btn_go.UseVisualStyleBackColor = True
        '
        'Cmb_sby
        '
        Me.Cmb_sby.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_sby.FormattingEnabled = True
        Me.Cmb_sby.Items.AddRange(New Object() {"id", "registeration no", "course", "fees", "Duration", "Timming", "starting date", "name", "place", "post", "pincode", "district", "phone no", "dob", "office name", "guardian name", "relation", "guardian phone no"})
        Me.Cmb_sby.Location = New System.Drawing.Point(91, 27)
        Me.Cmb_sby.Name = "Cmb_sby"
        Me.Cmb_sby.Size = New System.Drawing.Size(142, 25)
        Me.Cmb_sby.TabIndex = 49
        '
        'Txt_sdata
        '
        Me.Txt_sdata.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_sdata.Location = New System.Drawing.Point(425, 27)
        Me.Txt_sdata.Name = "Txt_sdata"
        Me.Txt_sdata.Size = New System.Drawing.Size(153, 23)
        Me.Txt_sdata.TabIndex = 48
        '
        'Lbl_sdata
        '
        Me.Lbl_sdata.AutoSize = True
        Me.Lbl_sdata.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_sdata.Location = New System.Drawing.Point(316, 31)
        Me.Lbl_sdata.Name = "Lbl_sdata"
        Me.Lbl_sdata.Size = New System.Drawing.Size(87, 17)
        Me.Lbl_sdata.TabIndex = 47
        Me.Lbl_sdata.Text = "Search data"
        '
        'Lbl_sby
        '
        Me.Lbl_sby.AutoSize = True
        Me.Lbl_sby.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_sby.Location = New System.Drawing.Point(11, 31)
        Me.Lbl_sby.Name = "Lbl_sby"
        Me.Lbl_sby.Size = New System.Drawing.Size(68, 17)
        Me.Lbl_sby.TabIndex = 46
        Me.Lbl_sby.Text = "Search By"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.Dgv_student_registration)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 593)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(670, 113)
        Me.GroupBox2.TabIndex = 120
        Me.GroupBox2.TabStop = False
        '
        'Dgv_student_registration
        '
        Me.Dgv_student_registration.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_student_registration.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dgv_student_registration.Location = New System.Drawing.Point(3, 16)
        Me.Dgv_student_registration.Name = "Dgv_student_registration"
        Me.Dgv_student_registration.Size = New System.Drawing.Size(664, 94)
        Me.Dgv_student_registration.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.btn_save)
        Me.GroupBox3.Controls.Add(Me.Btn_close)
        Me.GroupBox3.Controls.Add(Me.Btn_refresh)
        Me.GroupBox3.Controls.Add(Me.Btn_search)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 712)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(669, 52)
        Me.GroupBox3.TabIndex = 121
        Me.GroupBox3.TabStop = False
        '
        'btn_save
        '
        Me.btn_save.BackColor = System.Drawing.Color.Transparent
        Me.btn_save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_save.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save.ForeColor = System.Drawing.Color.Black
        Me.btn_save.Location = New System.Drawing.Point(17, 11)
        Me.btn_save.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(96, 30)
        Me.btn_save.TabIndex = 93
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = False
        '
        'Btn_close
        '
        Me.Btn_close.BackColor = System.Drawing.Color.Transparent
        Me.Btn_close.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_close.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_close.ForeColor = System.Drawing.Color.Black
        Me.Btn_close.Location = New System.Drawing.Point(518, 11)
        Me.Btn_close.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_close.Name = "Btn_close"
        Me.Btn_close.Size = New System.Drawing.Size(96, 30)
        Me.Btn_close.TabIndex = 92
        Me.Btn_close.Text = "Close"
        Me.Btn_close.UseVisualStyleBackColor = False
        '
        'Btn_refresh
        '
        Me.Btn_refresh.BackColor = System.Drawing.Color.Transparent
        Me.Btn_refresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_refresh.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_refresh.ForeColor = System.Drawing.Color.Black
        Me.Btn_refresh.Location = New System.Drawing.Point(338, 11)
        Me.Btn_refresh.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_refresh.Name = "Btn_refresh"
        Me.Btn_refresh.Size = New System.Drawing.Size(96, 30)
        Me.Btn_refresh.TabIndex = 91
        Me.Btn_refresh.Text = "Refresh"
        Me.Btn_refresh.UseVisualStyleBackColor = False
        '
        'Btn_search
        '
        Me.Btn_search.BackColor = System.Drawing.Color.Transparent
        Me.Btn_search.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_search.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_search.ForeColor = System.Drawing.Color.Black
        Me.Btn_search.Location = New System.Drawing.Point(161, 11)
        Me.Btn_search.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_search.Name = "Btn_search"
        Me.Btn_search.Size = New System.Drawing.Size(96, 30)
        Me.Btn_search.TabIndex = 90
        Me.Btn_search.Text = "Search"
        Me.Btn_search.UseVisualStyleBackColor = False
        '
        'frm_studentregistration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.OLE_BeautyClinic_v1._0.My.Resources.Resources.report
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(723, 766)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Dtp_da)
        Me.Controls.Add(Me.Dtp_date)
        Me.Controls.Add(Me.Lbl_c)
        Me.Controls.Add(Me.Lbl_co)
        Me.Controls.Add(Me.Lbl_e)
        Me.Controls.Add(Me.Lbl_i)
        Me.Controls.Add(Me.Lbl_m)
        Me.Controls.Add(Me.Lbl_g)
        Me.Controls.Add(Me.Lbl_r)
        Me.Controls.Add(Me.Lbl_gph)
        Me.Controls.Add(Me.Lbl_so)
        Me.Controls.Add(Me.Btn_browse)
        Me.Controls.Add(Me.Lbl_smco)
        Me.Controls.Add(Me.pb_stud)
        Me.Controls.Add(Me.Lbl_colom)
        Me.Controls.Add(Me.Txt_dis)
        Me.Controls.Add(Me.Lbl_me)
        Me.Controls.Add(Me.Lbl_dis)
        Me.Controls.Add(Me.Lbl_sa)
        Me.Controls.Add(Me.Txt_phno)
        Me.Controls.Add(Me.Lbl_mo)
        Me.Controls.Add(Me.Lbl_phno)
        Me.Controls.Add(Me.Lbl_mi)
        Me.Controls.Add(Me.Lbl_se)
        Me.Controls.Add(Me.Lbl_dob)
        Me.Controls.Add(Me.Lbl_s)
        Me.Controls.Add(Me.Txt_oname)
        Me.Controls.Add(Me.Lbl_semi)
        Me.Controls.Add(Me.Lbl_oname)
        Me.Controls.Add(Me.Txt_gname)
        Me.Controls.Add(Me.Lbl_gname)
        Me.Controls.Add(Me.Txt_relation)
        Me.Controls.Add(Me.Lbl_rela)
        Me.Controls.Add(Me.txt_gphno)
        Me.Controls.Add(Me.Lbl_gphno)
        Me.Controls.Add(Me.Txt_pin)
        Me.Controls.Add(Me.Lbl_pinc)
        Me.Controls.Add(Me.Txt_post)
        Me.Controls.Add(Me.Lbl_post)
        Me.Controls.Add(Me.Txt_place)
        Me.Controls.Add(Me.Lbl_place)
        Me.Controls.Add(Me.Txt_name)
        Me.Controls.Add(Me.Lbl_name)
        Me.Controls.Add(Me.Lbl_sdate)
        Me.Controls.Add(Me.Txt_timming)
        Me.Controls.Add(Me.Lbl_tmg)
        Me.Controls.Add(Me.Txt_dur)
        Me.Controls.Add(Me.Lbl_duration)
        Me.Controls.Add(Me.Txt_fee)
        Me.Controls.Add(Me.Lbl_fees)
        Me.Controls.Add(Me.Txt_course)
        Me.Controls.Add(Me.Lbl_course)
        Me.Controls.Add(Me.Txt_rgno)
        Me.Controls.Add(Me.Lbl_rgno)
        Me.Controls.Add(Me.Txt_id)
        Me.Controls.Add(Me.Lbl_id)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_studentregistration"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Student Registration"
        CType(Me.pb_stud, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.Dgv_student_registration, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Dtp_da As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_date As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbl_c As System.Windows.Forms.Label
    Friend WithEvents Lbl_co As System.Windows.Forms.Label
    Friend WithEvents Lbl_e As System.Windows.Forms.Label
    Friend WithEvents Lbl_i As System.Windows.Forms.Label
    Friend WithEvents Lbl_m As System.Windows.Forms.Label
    Friend WithEvents Lbl_g As System.Windows.Forms.Label
    Friend WithEvents Lbl_r As System.Windows.Forms.Label
    Friend WithEvents Lbl_gph As System.Windows.Forms.Label
    Friend WithEvents Lbl_so As System.Windows.Forms.Label
    Friend WithEvents Btn_browse As System.Windows.Forms.Button
    Friend WithEvents Lbl_smco As System.Windows.Forms.Label
    Friend WithEvents pb_stud As System.Windows.Forms.PictureBox
    Friend WithEvents Lbl_colom As System.Windows.Forms.Label
    Friend WithEvents Txt_dis As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_me As System.Windows.Forms.Label
    Friend WithEvents Lbl_dis As System.Windows.Forms.Label
    Friend WithEvents Lbl_sa As System.Windows.Forms.Label
    Friend WithEvents Txt_phno As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_mo As System.Windows.Forms.Label
    Friend WithEvents Lbl_phno As System.Windows.Forms.Label
    Friend WithEvents Lbl_mi As System.Windows.Forms.Label
    Friend WithEvents Lbl_se As System.Windows.Forms.Label
    Friend WithEvents Lbl_dob As System.Windows.Forms.Label
    Friend WithEvents Lbl_s As System.Windows.Forms.Label
    Friend WithEvents Txt_oname As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_semi As System.Windows.Forms.Label
    Friend WithEvents Lbl_oname As System.Windows.Forms.Label
    Friend WithEvents Txt_gname As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_gname As System.Windows.Forms.Label
    Friend WithEvents Txt_relation As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_rela As System.Windows.Forms.Label
    Friend WithEvents txt_gphno As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_gphno As System.Windows.Forms.Label
    Friend WithEvents Txt_pin As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_pinc As System.Windows.Forms.Label
    Friend WithEvents Txt_post As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_post As System.Windows.Forms.Label
    Friend WithEvents Txt_place As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_place As System.Windows.Forms.Label
    Friend WithEvents Txt_name As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_name As System.Windows.Forms.Label
    Friend WithEvents Lbl_sdate As System.Windows.Forms.Label
    Friend WithEvents Txt_timming As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_tmg As System.Windows.Forms.Label
    Friend WithEvents Txt_dur As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_duration As System.Windows.Forms.Label
    Friend WithEvents Txt_fee As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_fees As System.Windows.Forms.Label
    Friend WithEvents Txt_course As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_course As System.Windows.Forms.Label
    Friend WithEvents Txt_rgno As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_rgno As System.Windows.Forms.Label
    Friend WithEvents Txt_id As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_id As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_sco As System.Windows.Forms.Label
    Friend WithEvents Btn_go As System.Windows.Forms.Button
    Friend WithEvents Cmb_sby As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_sdata As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_sdata As System.Windows.Forms.Label
    Friend WithEvents Lbl_sby As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Dgv_student_registration As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_save As System.Windows.Forms.Button
    Friend WithEvents Btn_close As System.Windows.Forms.Button
    Friend WithEvents Btn_refresh As System.Windows.Forms.Button
    Friend WithEvents Btn_search As System.Windows.Forms.Button


    Friend WithEvents IdDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RegistrationnoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CourseDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FeesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DurationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TimmingDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartingdateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PlaceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PincodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DistrictDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhonenoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DobDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OfficenameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GuardiannameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RelationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GuardiannoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RecycleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
