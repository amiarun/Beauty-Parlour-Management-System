﻿Imports System.Data.SqlClient
Public Class frm_studentregistration
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_search.Click

    End Sub
    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_studentregistration(Registerno,name,Housename,place,post,pincode,District,Phoneno,salery,Joinningdate,Commingtime,Goingtime,Qualification)values('" + Txt_rgno.Text + "','" + Txt_course.Text + "','" + Txt_fee.Text + "','" + Txt_dur.Text + "','" + Txt_timming.Text + "','" + Dtp_date.Value + "','" + Txt_name.Text + "','" + Txt_place.Text + "','" + Txt_post.Text + "','" + Txt_pin.Text + "','" + Txt_dis.Text + "','" + Txt_phno.Text + "','" + Dtp_da.Value + "','" + Txt_oname.Text + "',,'" + Txt_gname.Text + "',,'" + Txt_relation.Text + "',,'" + txt_gphno.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim stud As New frm_studentregistration
                Me.Hide()
                stud.Show()

            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
    End Sub

    Private Sub frm_studentregistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ID AUTOMATIC READ
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select id from Tbl_studentregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            Txt_id.Text = dr.Item(0)
        End While
        dr.Close()
    End Sub

    Private Sub Btn_browse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_browse.Click

    End Sub

    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_close.Click
        Me.Close()
    End Sub

    Private Sub Btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_refresh.Click

    End Sub

    Private Sub Dgv_student_registration_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_student_registration.CellContentClick
        command = New SqlCommand("select*from Tbl_studentregistration ", connection)
        da = New SqlDataAdapter
        da.SelectCommand = command
        ds = New DataSet
        da.Fill(ds)
        Dgv_student_registration.DataSource = ds.Tables(0)
        Dgv_student_registration.Refresh()
    End Sub
End Class