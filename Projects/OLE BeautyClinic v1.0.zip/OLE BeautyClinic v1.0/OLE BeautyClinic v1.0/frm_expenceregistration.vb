﻿Imports System.Data.SqlClient
Public Class frm_expenceregistration
    Private a As Integer
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        
    End Sub
    Private Sub Btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub frm_expenceregistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'data grid veiw
        command = New SqlCommand("select*from Tbl_expenceregistration ", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        dgv_expence.DataSource = ds.Tables(0)
        dgv_expence.Refresh()
        'id
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select Id from Tbl_expenceregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            txt_id.Text = dr.Item(0) + 1
        End While
        dr.Close()
    End Sub

   

    Private Sub btn_save_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'try code
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_expenceregistration(Date,Particular,Amount)values('" + txt_particular.Text + "','" + txt_amount.Text + "','" + dtp_date.Value + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim expence As New frm_expenceregistration
                Me.Hide()
                expence.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
        'endof try code
    End Sub

    Private Sub Btn_search_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Btn_close_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()

    End Sub

    Private Sub grp_expence_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Btn_search_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_search.Click

    End Sub
End Class