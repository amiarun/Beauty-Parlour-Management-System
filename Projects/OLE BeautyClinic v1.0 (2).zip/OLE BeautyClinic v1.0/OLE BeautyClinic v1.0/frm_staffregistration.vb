﻿Imports System.Data.SqlClient
Public Class frm_staffregistration
    Private connection As New SqlConnection("Server=MALUTY\SQLEXPRESS;Database=beauty parlour;Integrated Security=true")
    Private command As New SqlCommand
    Private a As Integer
    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_close.Click, btn_update.Click, btn_delete.Click
        Me.Close()

    End Sub

    Private Sub frm_staffregistration_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ID AUTOMATIC READ
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("select id from Tbl_staffregistration", connection)
        dr = command.ExecuteReader
        While dr.Read
            txt_id.Text = dr.Item(0)
        End While
        dr.Close()
        'DATA GRID VIEW
        command = New SqlCommand("select * from Tbl_staffregistration", connection)
        da = New SqlDataAdapter(command)
        ds = New DataSet
        da.Fill(ds)
        Dgv_staffregistration.DataSource = ds.Tables(0)
        Dgv_staffregistration.Refresh()

    End Sub

   

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click
        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If
        command = New SqlCommand("insert into Tbl_staffregistration(Registerno,name,Housename,place,post,pincode,District,Phoneno,salery,Joinningdate,Commingtime,Goingtime,Qualification)values('" + txt_registerno.Text + "','" + txt_name.Text + "','" + dtp_joine.Value + "','" + txt_house.Text + "','" + Txt_place.Text + "','" + Txt_post.Text + "','" + Txt_pincode.Text + "','" + txt_district.Text + "','" + txt_phone.Text + "','" + Cbo_qualification.Text + "','" + txt_salary.Text + "','" + txt_comming.Text + "','" + Cbo_goingtime.Text + "')", connection)
        a = command.ExecuteNonQuery()
        If a > 0 Then
            MsgBox("successfully registred")
            If DialogResult.OK Then
                Dim staff As New frm_staffregistration
                Me.Hide()
                staff.Show()
            End If
        Else
            MsgBox("not  registred")
        End If
        connection.Close()
    End Sub

    Private Sub Btn_refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_refresh.Click

    End Sub

    Private Sub Btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_search.Click

    End Sub
End Class