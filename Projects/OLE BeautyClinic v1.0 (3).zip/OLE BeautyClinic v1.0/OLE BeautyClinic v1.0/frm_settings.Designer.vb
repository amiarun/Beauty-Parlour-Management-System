﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chk_setting = New System.Windows.Forms.CheckBox
        Me.chk_cashrep = New System.Windows.Forms.CheckBox
        Me.chk_expencerep = New System.Windows.Forms.CheckBox
        Me.chk_incomerep = New System.Windows.Forms.CheckBox
        Me.chk_billrep = New System.Windows.Forms.CheckBox
        Me.chk_bookingrep = New System.Windows.Forms.CheckBox
        Me.chk_servicerep = New System.Windows.Forms.CheckBox
        Me.chk_productrep = New System.Windows.Forms.CheckBox
        Me.chk_studentrep = New System.Windows.Forms.CheckBox
        Me.chk_staffrep = New System.Windows.Forms.CheckBox
        Me.chk_customerrep = New System.Windows.Forms.CheckBox
        Me.chk_cashreg = New System.Windows.Forms.CheckBox
        Me.chk_expencereg = New System.Windows.Forms.CheckBox
        Me.chk_incomereg = New System.Windows.Forms.CheckBox
        Me.chk_billreg = New System.Windows.Forms.CheckBox
        Me.chk_bookingreg = New System.Windows.Forms.CheckBox
        Me.chk_servicereg = New System.Windows.Forms.CheckBox
        Me.chk_productreg = New System.Windows.Forms.CheckBox
        Me.chk_studentreg = New System.Windows.Forms.CheckBox
        Me.chk_staffreg = New System.Windows.Forms.CheckBox
        Me.chk_customerreg = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Lbl_c = New System.Windows.Forms.Label
        Me.Lbl_so = New System.Windows.Forms.Label
        Me.Lbl_smco = New System.Windows.Forms.Label
        Me.Txt_reenter = New System.Windows.Forms.TextBox
        Me.Txt_password = New System.Windows.Forms.TextBox
        Me.Txt_user = New System.Windows.Forms.TextBox
        Me.Lbl_reenter = New System.Windows.Forms.Label
        Me.Lbl_password = New System.Windows.Forms.Label
        Me.Lbl_userna = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btn_save = New System.Windows.Forms.Button
        Me.Btn_close = New System.Windows.Forms.Button
        Me.Btn_refresh = New System.Windows.Forms.Button
        Me.Btn_search = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.chk_setting)
        Me.GroupBox2.Controls.Add(Me.chk_cashrep)
        Me.GroupBox2.Controls.Add(Me.chk_expencerep)
        Me.GroupBox2.Controls.Add(Me.chk_incomerep)
        Me.GroupBox2.Controls.Add(Me.chk_billrep)
        Me.GroupBox2.Controls.Add(Me.chk_bookingrep)
        Me.GroupBox2.Controls.Add(Me.chk_servicerep)
        Me.GroupBox2.Controls.Add(Me.chk_productrep)
        Me.GroupBox2.Controls.Add(Me.chk_studentrep)
        Me.GroupBox2.Controls.Add(Me.chk_staffrep)
        Me.GroupBox2.Controls.Add(Me.chk_customerrep)
        Me.GroupBox2.Controls.Add(Me.chk_cashreg)
        Me.GroupBox2.Controls.Add(Me.chk_expencereg)
        Me.GroupBox2.Controls.Add(Me.chk_incomereg)
        Me.GroupBox2.Controls.Add(Me.chk_billreg)
        Me.GroupBox2.Controls.Add(Me.chk_bookingreg)
        Me.GroupBox2.Controls.Add(Me.chk_servicereg)
        Me.GroupBox2.Controls.Add(Me.chk_productreg)
        Me.GroupBox2.Controls.Add(Me.chk_studentreg)
        Me.GroupBox2.Controls.Add(Me.chk_staffreg)
        Me.GroupBox2.Controls.Add(Me.chk_customerreg)
        Me.GroupBox2.Location = New System.Drawing.Point(55, 233)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(780, 187)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        '
        'chk_setting
        '
        Me.chk_setting.AutoSize = True
        Me.chk_setting.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_setting.ForeColor = System.Drawing.Color.White
        Me.chk_setting.Location = New System.Drawing.Point(523, 157)
        Me.chk_setting.Name = "chk_setting"
        Me.chk_setting.Size = New System.Drawing.Size(76, 24)
        Me.chk_setting.TabIndex = 20
        Me.chk_setting.Text = "setting"
        Me.chk_setting.UseVisualStyleBackColor = True
        '
        'chk_cashrep
        '
        Me.chk_cashrep.AutoSize = True
        Me.chk_cashrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_cashrep.ForeColor = System.Drawing.Color.White
        Me.chk_cashrep.Location = New System.Drawing.Point(580, 137)
        Me.chk_cashrep.Name = "chk_cashrep"
        Me.chk_cashrep.Size = New System.Drawing.Size(114, 24)
        Me.chk_cashrep.TabIndex = 19
        Me.chk_cashrep.Text = "Cash report"
        Me.chk_cashrep.UseVisualStyleBackColor = True
        '
        'chk_expencerep
        '
        Me.chk_expencerep.AutoSize = True
        Me.chk_expencerep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_expencerep.ForeColor = System.Drawing.Color.White
        Me.chk_expencerep.Location = New System.Drawing.Point(580, 107)
        Me.chk_expencerep.Name = "chk_expencerep"
        Me.chk_expencerep.Size = New System.Drawing.Size(145, 24)
        Me.chk_expencerep.TabIndex = 18
        Me.chk_expencerep.Text = "Expence Report"
        Me.chk_expencerep.UseVisualStyleBackColor = True
        '
        'chk_incomerep
        '
        Me.chk_incomerep.AutoSize = True
        Me.chk_incomerep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_incomerep.ForeColor = System.Drawing.Color.White
        Me.chk_incomerep.Location = New System.Drawing.Point(580, 77)
        Me.chk_incomerep.Name = "chk_incomerep"
        Me.chk_incomerep.Size = New System.Drawing.Size(138, 24)
        Me.chk_incomerep.TabIndex = 17
        Me.chk_incomerep.Text = "Income Report"
        Me.chk_incomerep.UseVisualStyleBackColor = True
        '
        'chk_billrep
        '
        Me.chk_billrep.AutoSize = True
        Me.chk_billrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_billrep.ForeColor = System.Drawing.Color.White
        Me.chk_billrep.Location = New System.Drawing.Point(580, 47)
        Me.chk_billrep.Name = "chk_billrep"
        Me.chk_billrep.Size = New System.Drawing.Size(121, 24)
        Me.chk_billrep.TabIndex = 16
        Me.chk_billrep.Text = "Billing Report"
        Me.chk_billrep.UseVisualStyleBackColor = True
        '
        'chk_bookingrep
        '
        Me.chk_bookingrep.AutoSize = True
        Me.chk_bookingrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_bookingrep.ForeColor = System.Drawing.Color.White
        Me.chk_bookingrep.Location = New System.Drawing.Point(580, 17)
        Me.chk_bookingrep.Name = "chk_bookingrep"
        Me.chk_bookingrep.Size = New System.Drawing.Size(140, 24)
        Me.chk_bookingrep.TabIndex = 15
        Me.chk_bookingrep.Text = "Booking Report"
        Me.chk_bookingrep.UseVisualStyleBackColor = True
        '
        'chk_servicerep
        '
        Me.chk_servicerep.AutoSize = True
        Me.chk_servicerep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_servicerep.ForeColor = System.Drawing.Color.White
        Me.chk_servicerep.Location = New System.Drawing.Point(395, 137)
        Me.chk_servicerep.Name = "chk_servicerep"
        Me.chk_servicerep.Size = New System.Drawing.Size(136, 24)
        Me.chk_servicerep.TabIndex = 14
        Me.chk_servicerep.Text = "Service Report"
        Me.chk_servicerep.UseVisualStyleBackColor = True
        '
        'chk_productrep
        '
        Me.chk_productrep.AutoSize = True
        Me.chk_productrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_productrep.ForeColor = System.Drawing.Color.White
        Me.chk_productrep.Location = New System.Drawing.Point(395, 107)
        Me.chk_productrep.Name = "chk_productrep"
        Me.chk_productrep.Size = New System.Drawing.Size(139, 24)
        Me.chk_productrep.TabIndex = 13
        Me.chk_productrep.Text = "Product Report"
        Me.chk_productrep.UseVisualStyleBackColor = True
        '
        'chk_studentrep
        '
        Me.chk_studentrep.AutoSize = True
        Me.chk_studentrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_studentrep.ForeColor = System.Drawing.Color.White
        Me.chk_studentrep.Location = New System.Drawing.Point(396, 77)
        Me.chk_studentrep.Name = "chk_studentrep"
        Me.chk_studentrep.Size = New System.Drawing.Size(136, 24)
        Me.chk_studentrep.TabIndex = 12
        Me.chk_studentrep.Text = "Student Report"
        Me.chk_studentrep.UseVisualStyleBackColor = True
        '
        'chk_staffrep
        '
        Me.chk_staffrep.AutoSize = True
        Me.chk_staffrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_staffrep.ForeColor = System.Drawing.Color.White
        Me.chk_staffrep.Location = New System.Drawing.Point(396, 47)
        Me.chk_staffrep.Name = "chk_staffrep"
        Me.chk_staffrep.Size = New System.Drawing.Size(113, 24)
        Me.chk_staffrep.TabIndex = 11
        Me.chk_staffrep.Text = "Staff Report"
        Me.chk_staffrep.UseVisualStyleBackColor = True
        '
        'chk_customerrep
        '
        Me.chk_customerrep.AutoSize = True
        Me.chk_customerrep.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_customerrep.ForeColor = System.Drawing.Color.White
        Me.chk_customerrep.Location = New System.Drawing.Point(395, 21)
        Me.chk_customerrep.Name = "chk_customerrep"
        Me.chk_customerrep.Size = New System.Drawing.Size(151, 24)
        Me.chk_customerrep.TabIndex = 10
        Me.chk_customerrep.Text = "Customer Report"
        Me.chk_customerrep.UseVisualStyleBackColor = True
        '
        'chk_cashreg
        '
        Me.chk_cashreg.AutoSize = True
        Me.chk_cashreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_cashreg.ForeColor = System.Drawing.Color.White
        Me.chk_cashreg.Location = New System.Drawing.Point(199, 137)
        Me.chk_cashreg.Name = "chk_cashreg"
        Me.chk_cashreg.Size = New System.Drawing.Size(111, 24)
        Me.chk_cashreg.TabIndex = 9
        Me.chk_cashreg.Text = "Cash book "
        Me.chk_cashreg.UseVisualStyleBackColor = True
        '
        'chk_expencereg
        '
        Me.chk_expencereg.AutoSize = True
        Me.chk_expencereg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_expencereg.ForeColor = System.Drawing.Color.White
        Me.chk_expencereg.Location = New System.Drawing.Point(199, 107)
        Me.chk_expencereg.Name = "chk_expencereg"
        Me.chk_expencereg.Size = New System.Drawing.Size(181, 24)
        Me.chk_expencereg.TabIndex = 8
        Me.chk_expencereg.Text = "Expence Registartion"
        Me.chk_expencereg.UseVisualStyleBackColor = True
        '
        'chk_incomereg
        '
        Me.chk_incomereg.AutoSize = True
        Me.chk_incomereg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_incomereg.ForeColor = System.Drawing.Color.White
        Me.chk_incomereg.Location = New System.Drawing.Point(199, 77)
        Me.chk_incomereg.Name = "chk_incomereg"
        Me.chk_incomereg.Size = New System.Drawing.Size(174, 24)
        Me.chk_incomereg.TabIndex = 7
        Me.chk_incomereg.Text = "Income Registration"
        Me.chk_incomereg.UseVisualStyleBackColor = True
        '
        'chk_billreg
        '
        Me.chk_billreg.AutoSize = True
        Me.chk_billreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_billreg.ForeColor = System.Drawing.Color.White
        Me.chk_billreg.Location = New System.Drawing.Point(199, 47)
        Me.chk_billreg.Name = "chk_billreg"
        Me.chk_billreg.Size = New System.Drawing.Size(157, 24)
        Me.chk_billreg.TabIndex = 6
        Me.chk_billreg.Text = "Billing Registration"
        Me.chk_billreg.UseVisualStyleBackColor = True
        '
        'chk_bookingreg
        '
        Me.chk_bookingreg.AutoSize = True
        Me.chk_bookingreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_bookingreg.ForeColor = System.Drawing.Color.White
        Me.chk_bookingreg.Location = New System.Drawing.Point(199, 17)
        Me.chk_bookingreg.Name = "chk_bookingreg"
        Me.chk_bookingreg.Size = New System.Drawing.Size(176, 24)
        Me.chk_bookingreg.TabIndex = 5
        Me.chk_bookingreg.Text = "Booking Registration"
        Me.chk_bookingreg.UseVisualStyleBackColor = True
        '
        'chk_servicereg
        '
        Me.chk_servicereg.AutoSize = True
        Me.chk_servicereg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_servicereg.ForeColor = System.Drawing.Color.White
        Me.chk_servicereg.Location = New System.Drawing.Point(14, 137)
        Me.chk_servicereg.Name = "chk_servicereg"
        Me.chk_servicereg.Size = New System.Drawing.Size(172, 24)
        Me.chk_servicereg.TabIndex = 4
        Me.chk_servicereg.Text = "Service Registration"
        Me.chk_servicereg.UseVisualStyleBackColor = True
        '
        'chk_productreg
        '
        Me.chk_productreg.AutoSize = True
        Me.chk_productreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_productreg.ForeColor = System.Drawing.Color.White
        Me.chk_productreg.Location = New System.Drawing.Point(14, 107)
        Me.chk_productreg.Name = "chk_productreg"
        Me.chk_productreg.Size = New System.Drawing.Size(175, 24)
        Me.chk_productreg.TabIndex = 3
        Me.chk_productreg.Text = "Product Registration"
        Me.chk_productreg.UseVisualStyleBackColor = True
        '
        'chk_studentreg
        '
        Me.chk_studentreg.AutoSize = True
        Me.chk_studentreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_studentreg.ForeColor = System.Drawing.Color.White
        Me.chk_studentreg.Location = New System.Drawing.Point(15, 77)
        Me.chk_studentreg.Name = "chk_studentreg"
        Me.chk_studentreg.Size = New System.Drawing.Size(172, 24)
        Me.chk_studentreg.TabIndex = 2
        Me.chk_studentreg.Text = "Student Registration"
        Me.chk_studentreg.UseVisualStyleBackColor = True
        '
        'chk_staffreg
        '
        Me.chk_staffreg.AutoSize = True
        Me.chk_staffreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_staffreg.ForeColor = System.Drawing.Color.White
        Me.chk_staffreg.Location = New System.Drawing.Point(15, 47)
        Me.chk_staffreg.Name = "chk_staffreg"
        Me.chk_staffreg.Size = New System.Drawing.Size(149, 24)
        Me.chk_staffreg.TabIndex = 1
        Me.chk_staffreg.Text = "Staff Registration"
        Me.chk_staffreg.UseVisualStyleBackColor = True
        '
        'chk_customerreg
        '
        Me.chk_customerreg.AutoSize = True
        Me.chk_customerreg.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk_customerreg.ForeColor = System.Drawing.Color.White
        Me.chk_customerreg.Location = New System.Drawing.Point(14, 21)
        Me.chk_customerreg.Name = "chk_customerreg"
        Me.chk_customerreg.Size = New System.Drawing.Size(187, 24)
        Me.chk_customerreg.TabIndex = 0
        Me.chk_customerreg.Text = "Customer Registration"
        Me.chk_customerreg.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Lbl_c)
        Me.GroupBox1.Controls.Add(Me.Lbl_so)
        Me.GroupBox1.Controls.Add(Me.Lbl_smco)
        Me.GroupBox1.Controls.Add(Me.Txt_reenter)
        Me.GroupBox1.Controls.Add(Me.Txt_password)
        Me.GroupBox1.Controls.Add(Me.Txt_user)
        Me.GroupBox1.Controls.Add(Me.Lbl_reenter)
        Me.GroupBox1.Controls.Add(Me.Lbl_password)
        Me.GroupBox1.Controls.Add(Me.Lbl_userna)
        Me.GroupBox1.Location = New System.Drawing.Point(60, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(774, 161)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        '
        'Lbl_c
        '
        Me.Lbl_c.AutoSize = True
        Me.Lbl_c.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_c.ForeColor = System.Drawing.Color.White
        Me.Lbl_c.Location = New System.Drawing.Point(296, 110)
        Me.Lbl_c.Name = "Lbl_c"
        Me.Lbl_c.Size = New System.Drawing.Size(19, 25)
        Me.Lbl_c.TabIndex = 72
        Me.Lbl_c.Text = ":"
        '
        'Lbl_so
        '
        Me.Lbl_so.AutoSize = True
        Me.Lbl_so.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_so.ForeColor = System.Drawing.Color.White
        Me.Lbl_so.Location = New System.Drawing.Point(296, 25)
        Me.Lbl_so.Name = "Lbl_so"
        Me.Lbl_so.Size = New System.Drawing.Size(19, 25)
        Me.Lbl_so.TabIndex = 71
        Me.Lbl_so.Text = ":"
        '
        'Lbl_smco
        '
        Me.Lbl_smco.AutoSize = True
        Me.Lbl_smco.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_smco.ForeColor = System.Drawing.Color.White
        Me.Lbl_smco.Location = New System.Drawing.Point(296, 67)
        Me.Lbl_smco.Name = "Lbl_smco"
        Me.Lbl_smco.Size = New System.Drawing.Size(19, 25)
        Me.Lbl_smco.TabIndex = 70
        Me.Lbl_smco.Text = ":"
        '
        'Txt_reenter
        '
        Me.Txt_reenter.ForeColor = System.Drawing.Color.Black
        Me.Txt_reenter.Location = New System.Drawing.Point(338, 109)
        Me.Txt_reenter.Multiline = True
        Me.Txt_reenter.Name = "Txt_reenter"
        Me.Txt_reenter.Size = New System.Drawing.Size(183, 28)
        Me.Txt_reenter.TabIndex = 69
        '
        'Txt_password
        '
        Me.Txt_password.ForeColor = System.Drawing.Color.Black
        Me.Txt_password.Location = New System.Drawing.Point(338, 67)
        Me.Txt_password.Multiline = True
        Me.Txt_password.Name = "Txt_password"
        Me.Txt_password.Size = New System.Drawing.Size(183, 28)
        Me.Txt_password.TabIndex = 68
        '
        'Txt_user
        '
        Me.Txt_user.ForeColor = System.Drawing.Color.Black
        Me.Txt_user.Location = New System.Drawing.Point(338, 25)
        Me.Txt_user.Multiline = True
        Me.Txt_user.Name = "Txt_user"
        Me.Txt_user.Size = New System.Drawing.Size(183, 28)
        Me.Txt_user.TabIndex = 67
        '
        'Lbl_reenter
        '
        Me.Lbl_reenter.AutoSize = True
        Me.Lbl_reenter.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_reenter.ForeColor = System.Drawing.Color.White
        Me.Lbl_reenter.Location = New System.Drawing.Point(55, 115)
        Me.Lbl_reenter.Name = "Lbl_reenter"
        Me.Lbl_reenter.Size = New System.Drawing.Size(186, 21)
        Me.Lbl_reenter.TabIndex = 66
        Me.Lbl_reenter.Text = "Re-enter the password"
        '
        'Lbl_password
        '
        Me.Lbl_password.AutoSize = True
        Me.Lbl_password.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_password.ForeColor = System.Drawing.Color.White
        Me.Lbl_password.Location = New System.Drawing.Point(55, 70)
        Me.Lbl_password.Name = "Lbl_password"
        Me.Lbl_password.Size = New System.Drawing.Size(84, 21)
        Me.Lbl_password.TabIndex = 65
        Me.Lbl_password.Text = "password"
        '
        'Lbl_userna
        '
        Me.Lbl_userna.AutoSize = True
        Me.Lbl_userna.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_userna.ForeColor = System.Drawing.Color.White
        Me.Lbl_userna.Location = New System.Drawing.Point(55, 25)
        Me.Lbl_userna.Name = "Lbl_userna"
        Me.Lbl_userna.Size = New System.Drawing.Size(189, 21)
        Me.Lbl_userna.TabIndex = 64
        Me.Lbl_userna.Text = "Create new user name"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.btn_save)
        Me.GroupBox3.Controls.Add(Me.Btn_close)
        Me.GroupBox3.Controls.Add(Me.Btn_refresh)
        Me.GroupBox3.Controls.Add(Me.Btn_search)
        Me.GroupBox3.Location = New System.Drawing.Point(55, 440)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(774, 66)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        '
        'btn_save
        '
        Me.btn_save.BackColor = System.Drawing.Color.Transparent
        Me.btn_save.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.btn_save.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save.ForeColor = System.Drawing.Color.Black
        Me.btn_save.Location = New System.Drawing.Point(15, 19)
        Me.btn_save.Margin = New System.Windows.Forms.Padding(2)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(96, 30)
        Me.btn_save.TabIndex = 83
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = False
        '
        'Btn_close
        '
        Me.Btn_close.BackColor = System.Drawing.Color.Transparent
        Me.Btn_close.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Btn_close.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_close.ForeColor = System.Drawing.Color.Black
        Me.Btn_close.Location = New System.Drawing.Point(642, 19)
        Me.Btn_close.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_close.Name = "Btn_close"
        Me.Btn_close.Size = New System.Drawing.Size(96, 30)
        Me.Btn_close.TabIndex = 82
        Me.Btn_close.Text = "Close"
        Me.Btn_close.UseVisualStyleBackColor = False
        '
        'Btn_refresh
        '
        Me.Btn_refresh.BackColor = System.Drawing.Color.Transparent
        Me.Btn_refresh.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Btn_refresh.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_refresh.ForeColor = System.Drawing.Color.Black
        Me.Btn_refresh.Location = New System.Drawing.Point(433, 19)
        Me.Btn_refresh.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_refresh.Name = "Btn_refresh"
        Me.Btn_refresh.Size = New System.Drawing.Size(96, 30)
        Me.Btn_refresh.TabIndex = 81
        Me.Btn_refresh.Text = "Refresh"
        Me.Btn_refresh.UseVisualStyleBackColor = False
        '
        'Btn_search
        '
        Me.Btn_search.BackColor = System.Drawing.Color.Transparent
        Me.Btn_search.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Btn_search.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_search.ForeColor = System.Drawing.Color.Black
        Me.Btn_search.Location = New System.Drawing.Point(224, 19)
        Me.Btn_search.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_search.Name = "Btn_search"
        Me.Btn_search.Size = New System.Drawing.Size(96, 30)
        Me.Btn_search.TabIndex = 80
        Me.Btn_search.Text = "Search"
        Me.Btn_search.UseVisualStyleBackColor = False
        '
        'frm_settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.OLE_BeautyClinic_v1._0.My.Resources.Resources.settings
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(880, 546)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_settings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Settings"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_c As System.Windows.Forms.Label
    Friend WithEvents Lbl_so As System.Windows.Forms.Label
    Friend WithEvents Lbl_smco As System.Windows.Forms.Label
    Friend WithEvents Txt_reenter As System.Windows.Forms.TextBox
    Friend WithEvents Txt_password As System.Windows.Forms.TextBox
    Friend WithEvents Txt_user As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_reenter As System.Windows.Forms.Label
    Friend WithEvents Lbl_password As System.Windows.Forms.Label
    Friend WithEvents Lbl_userna As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_save As System.Windows.Forms.Button
    Friend WithEvents Btn_close As System.Windows.Forms.Button
    Friend WithEvents Btn_refresh As System.Windows.Forms.Button
    Friend WithEvents Btn_search As System.Windows.Forms.Button
    Friend WithEvents chk_customerreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_productreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_studentreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_staffreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_cashreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_expencereg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_incomereg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_billreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_bookingreg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_servicereg As System.Windows.Forms.CheckBox
    Friend WithEvents chk_cashrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_expencerep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_incomerep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_billrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_bookingrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_servicerep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_productrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_studentrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_staffrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_customerrep As System.Windows.Forms.CheckBox
    Friend WithEvents chk_setting As System.Windows.Forms.CheckBox
End Class
