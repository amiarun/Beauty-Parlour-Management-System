﻿Public Class frm_staffprint

    Private Sub frm_staffprint_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub
End Class