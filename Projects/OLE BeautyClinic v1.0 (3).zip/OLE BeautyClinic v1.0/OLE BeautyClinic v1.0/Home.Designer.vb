﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_login = New System.Windows.Forms.Button
        Me.btn_customerreg = New System.Windows.Forms.Button
        Me.btn_staffreg = New System.Windows.Forms.Button
        Me.btn_servicereg = New System.Windows.Forms.Button
        Me.btn_productreg = New System.Windows.Forms.Button
        Me.btn_studentreg = New System.Windows.Forms.Button
        Me.btn_cashreg = New System.Windows.Forms.Button
        Me.btn_expencereg = New System.Windows.Forms.Button
        Me.btn_incomereg = New System.Windows.Forms.Button
        Me.btn_billingreg = New System.Windows.Forms.Button
        Me.btn_bookingreg = New System.Windows.Forms.Button
        Me.btn_studentrep = New System.Windows.Forms.Button
        Me.btn_productrep = New System.Windows.Forms.Button
        Me.btn_servicerep = New System.Windows.Forms.Button
        Me.btn_staffrep = New System.Windows.Forms.Button
        Me.btn_customerrep = New System.Windows.Forms.Button
        Me.btn_cashrep = New System.Windows.Forms.Button
        Me.btn_expencerep = New System.Windows.Forms.Button
        Me.btn_incomerep = New System.Windows.Forms.Button
        Me.btn_billrep = New System.Windows.Forms.Button
        Me.btn_bookingrep = New System.Windows.Forms.Button
        Me.btn_settings = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'btn_login
        '
        Me.btn_login.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_login.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_login.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btn_login.Location = New System.Drawing.Point(793, 52)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(111, 33)
        Me.btn_login.TabIndex = 0
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = False
        '
        'btn_customerreg
        '
        Me.btn_customerreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_customerreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_customerreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_customerreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customerreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_customerreg.Location = New System.Drawing.Point(60, 220)
        Me.btn_customerreg.Name = "btn_customerreg"
        Me.btn_customerreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_customerreg.TabIndex = 1
        Me.btn_customerreg.Text = "Customer Registration"
        Me.btn_customerreg.UseVisualStyleBackColor = False
        '
        'btn_staffreg
        '
        Me.btn_staffreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_staffreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_staffreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_staffreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staffreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_staffreg.Location = New System.Drawing.Point(60, 262)
        Me.btn_staffreg.Name = "btn_staffreg"
        Me.btn_staffreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_staffreg.TabIndex = 2
        Me.btn_staffreg.Text = "Staff Registration"
        Me.btn_staffreg.UseVisualStyleBackColor = False
        '
        'btn_servicereg
        '
        Me.btn_servicereg.BackColor = System.Drawing.Color.Transparent
        Me.btn_servicereg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_servicereg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_servicereg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_servicereg.ForeColor = System.Drawing.Color.Snow
        Me.btn_servicereg.Location = New System.Drawing.Point(60, 304)
        Me.btn_servicereg.Name = "btn_servicereg"
        Me.btn_servicereg.Size = New System.Drawing.Size(175, 30)
        Me.btn_servicereg.TabIndex = 3
        Me.btn_servicereg.Text = "Service Registration"
        Me.btn_servicereg.UseVisualStyleBackColor = False
        '
        'btn_productreg
        '
        Me.btn_productreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_productreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_productreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_productreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_productreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_productreg.Location = New System.Drawing.Point(60, 346)
        Me.btn_productreg.Name = "btn_productreg"
        Me.btn_productreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_productreg.TabIndex = 4
        Me.btn_productreg.Text = "Product Registration"
        Me.btn_productreg.UseVisualStyleBackColor = False
        '
        'btn_studentreg
        '
        Me.btn_studentreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_studentreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_studentreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_studentreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_studentreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_studentreg.Location = New System.Drawing.Point(60, 388)
        Me.btn_studentreg.Name = "btn_studentreg"
        Me.btn_studentreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_studentreg.TabIndex = 5
        Me.btn_studentreg.Text = "Student Registration"
        Me.btn_studentreg.UseVisualStyleBackColor = False
        '
        'btn_cashreg
        '
        Me.btn_cashreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_cashreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_cashreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_cashreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cashreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_cashreg.Location = New System.Drawing.Point(286, 388)
        Me.btn_cashreg.Name = "btn_cashreg"
        Me.btn_cashreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_cashreg.TabIndex = 10
        Me.btn_cashreg.Text = "Cashbook Registration"
        Me.btn_cashreg.UseVisualStyleBackColor = False
        '
        'btn_expencereg
        '
        Me.btn_expencereg.BackColor = System.Drawing.Color.Transparent
        Me.btn_expencereg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_expencereg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_expencereg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_expencereg.ForeColor = System.Drawing.Color.Snow
        Me.btn_expencereg.Location = New System.Drawing.Point(286, 346)
        Me.btn_expencereg.Name = "btn_expencereg"
        Me.btn_expencereg.Size = New System.Drawing.Size(175, 30)
        Me.btn_expencereg.TabIndex = 9
        Me.btn_expencereg.Text = "Expence Registration"
        Me.btn_expencereg.UseVisualStyleBackColor = False
        '
        'btn_incomereg
        '
        Me.btn_incomereg.BackColor = System.Drawing.Color.Transparent
        Me.btn_incomereg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_incomereg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_incomereg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_incomereg.ForeColor = System.Drawing.Color.Snow
        Me.btn_incomereg.Location = New System.Drawing.Point(286, 304)
        Me.btn_incomereg.Name = "btn_incomereg"
        Me.btn_incomereg.Size = New System.Drawing.Size(175, 30)
        Me.btn_incomereg.TabIndex = 8
        Me.btn_incomereg.Text = "Income Registration"
        Me.btn_incomereg.UseVisualStyleBackColor = False
        '
        'btn_billingreg
        '
        Me.btn_billingreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_billingreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_billingreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_billingreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_billingreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_billingreg.Location = New System.Drawing.Point(286, 262)
        Me.btn_billingreg.Name = "btn_billingreg"
        Me.btn_billingreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_billingreg.TabIndex = 7
        Me.btn_billingreg.Text = "Billing Registration"
        Me.btn_billingreg.UseVisualStyleBackColor = False
        '
        'btn_bookingreg
        '
        Me.btn_bookingreg.BackColor = System.Drawing.Color.Transparent
        Me.btn_bookingreg.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_bookingreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_bookingreg.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_bookingreg.ForeColor = System.Drawing.Color.Snow
        Me.btn_bookingreg.Location = New System.Drawing.Point(286, 220)
        Me.btn_bookingreg.Name = "btn_bookingreg"
        Me.btn_bookingreg.Size = New System.Drawing.Size(175, 30)
        Me.btn_bookingreg.TabIndex = 6
        Me.btn_bookingreg.Text = "Booking Registration"
        Me.btn_bookingreg.UseVisualStyleBackColor = False
        '
        'btn_studentrep
        '
        Me.btn_studentrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_studentrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_studentrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_studentrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_studentrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_studentrep.Location = New System.Drawing.Point(527, 388)
        Me.btn_studentrep.Name = "btn_studentrep"
        Me.btn_studentrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_studentrep.TabIndex = 15
        Me.btn_studentrep.Text = "Student Report"
        Me.btn_studentrep.UseVisualStyleBackColor = False
        '
        'btn_productrep
        '
        Me.btn_productrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_productrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_productrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_productrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_productrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_productrep.Location = New System.Drawing.Point(527, 346)
        Me.btn_productrep.Name = "btn_productrep"
        Me.btn_productrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_productrep.TabIndex = 14
        Me.btn_productrep.Text = "Product Report"
        Me.btn_productrep.UseVisualStyleBackColor = False
        '
        'btn_servicerep
        '
        Me.btn_servicerep.BackColor = System.Drawing.Color.Transparent
        Me.btn_servicerep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_servicerep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_servicerep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_servicerep.ForeColor = System.Drawing.Color.Snow
        Me.btn_servicerep.Location = New System.Drawing.Point(527, 304)
        Me.btn_servicerep.Name = "btn_servicerep"
        Me.btn_servicerep.Size = New System.Drawing.Size(175, 30)
        Me.btn_servicerep.TabIndex = 13
        Me.btn_servicerep.Text = "Service Report"
        Me.btn_servicerep.UseVisualStyleBackColor = False
        '
        'btn_staffrep
        '
        Me.btn_staffrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_staffrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_staffrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_staffrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_staffrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_staffrep.Location = New System.Drawing.Point(527, 262)
        Me.btn_staffrep.Name = "btn_staffrep"
        Me.btn_staffrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_staffrep.TabIndex = 12
        Me.btn_staffrep.Text = "Staff Report"
        Me.btn_staffrep.UseVisualStyleBackColor = False
        '
        'btn_customerrep
        '
        Me.btn_customerrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_customerrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_customerrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_customerrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_customerrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_customerrep.Location = New System.Drawing.Point(527, 220)
        Me.btn_customerrep.Name = "btn_customerrep"
        Me.btn_customerrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_customerrep.TabIndex = 11
        Me.btn_customerrep.Text = "Customer report"
        Me.btn_customerrep.UseVisualStyleBackColor = False
        '
        'btn_cashrep
        '
        Me.btn_cashrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_cashrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_cashrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_cashrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cashrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_cashrep.Location = New System.Drawing.Point(729, 388)
        Me.btn_cashrep.Name = "btn_cashrep"
        Me.btn_cashrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_cashrep.TabIndex = 20
        Me.btn_cashrep.Text = "Cashbook Report"
        Me.btn_cashrep.UseVisualStyleBackColor = False
        '
        'btn_expencerep
        '
        Me.btn_expencerep.BackColor = System.Drawing.Color.Transparent
        Me.btn_expencerep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_expencerep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_expencerep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_expencerep.ForeColor = System.Drawing.Color.Snow
        Me.btn_expencerep.Location = New System.Drawing.Point(729, 346)
        Me.btn_expencerep.Name = "btn_expencerep"
        Me.btn_expencerep.Size = New System.Drawing.Size(175, 30)
        Me.btn_expencerep.TabIndex = 19
        Me.btn_expencerep.Text = "Expense Report"
        Me.btn_expencerep.UseVisualStyleBackColor = False
        '
        'btn_incomerep
        '
        Me.btn_incomerep.BackColor = System.Drawing.Color.Transparent
        Me.btn_incomerep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_incomerep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_incomerep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_incomerep.ForeColor = System.Drawing.Color.Snow
        Me.btn_incomerep.Location = New System.Drawing.Point(729, 304)
        Me.btn_incomerep.Name = "btn_incomerep"
        Me.btn_incomerep.Size = New System.Drawing.Size(175, 30)
        Me.btn_incomerep.TabIndex = 18
        Me.btn_incomerep.Text = "Income Report"
        Me.btn_incomerep.UseVisualStyleBackColor = False
        '
        'btn_billrep
        '
        Me.btn_billrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_billrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_billrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_billrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_billrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_billrep.Location = New System.Drawing.Point(729, 262)
        Me.btn_billrep.Name = "btn_billrep"
        Me.btn_billrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_billrep.TabIndex = 17
        Me.btn_billrep.Text = "Billing Report"
        Me.btn_billrep.UseVisualStyleBackColor = False
        '
        'btn_bookingrep
        '
        Me.btn_bookingrep.BackColor = System.Drawing.Color.Transparent
        Me.btn_bookingrep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_bookingrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_bookingrep.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_bookingrep.ForeColor = System.Drawing.Color.Snow
        Me.btn_bookingrep.Location = New System.Drawing.Point(729, 220)
        Me.btn_bookingrep.Name = "btn_bookingrep"
        Me.btn_bookingrep.Size = New System.Drawing.Size(175, 30)
        Me.btn_bookingrep.TabIndex = 16
        Me.btn_bookingrep.Text = "Booking Report"
        Me.btn_bookingrep.UseVisualStyleBackColor = False
        '
        'btn_settings
        '
        Me.btn_settings.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btn_settings.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_settings.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_settings.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btn_settings.Location = New System.Drawing.Point(763, 471)
        Me.btn_settings.Name = "btn_settings"
        Me.btn_settings.Size = New System.Drawing.Size(141, 41)
        Me.btn_settings.TabIndex = 21
        Me.btn_settings.Text = "Settings"
        Me.btn_settings.UseVisualStyleBackColor = False
        '
        'frm_home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.OLE_BeautyClinic_v1._0.My.Resources.Resources.project
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(940, 532)
        Me.Controls.Add(Me.btn_settings)
        Me.Controls.Add(Me.btn_cashrep)
        Me.Controls.Add(Me.btn_expencerep)
        Me.Controls.Add(Me.btn_incomerep)
        Me.Controls.Add(Me.btn_billrep)
        Me.Controls.Add(Me.btn_bookingrep)
        Me.Controls.Add(Me.btn_studentrep)
        Me.Controls.Add(Me.btn_productrep)
        Me.Controls.Add(Me.btn_servicerep)
        Me.Controls.Add(Me.btn_staffrep)
        Me.Controls.Add(Me.btn_customerrep)
        Me.Controls.Add(Me.btn_cashreg)
        Me.Controls.Add(Me.btn_expencereg)
        Me.Controls.Add(Me.btn_incomereg)
        Me.Controls.Add(Me.btn_billingreg)
        Me.Controls.Add(Me.btn_bookingreg)
        Me.Controls.Add(Me.btn_studentreg)
        Me.Controls.Add(Me.btn_productreg)
        Me.Controls.Add(Me.btn_servicereg)
        Me.Controls.Add(Me.btn_staffreg)
        Me.Controls.Add(Me.btn_customerreg)
        Me.Controls.Add(Me.btn_login)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frm_home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Home"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_login As System.Windows.Forms.Button
    Friend WithEvents btn_customerreg As System.Windows.Forms.Button
    Friend WithEvents btn_staffreg As System.Windows.Forms.Button
    Friend WithEvents btn_servicereg As System.Windows.Forms.Button
    Friend WithEvents btn_productreg As System.Windows.Forms.Button
    Friend WithEvents btn_studentreg As System.Windows.Forms.Button
    Friend WithEvents btn_cashreg As System.Windows.Forms.Button
    Friend WithEvents btn_expencereg As System.Windows.Forms.Button
    Friend WithEvents btn_incomereg As System.Windows.Forms.Button
    Friend WithEvents btn_billingreg As System.Windows.Forms.Button
    Friend WithEvents btn_bookingreg As System.Windows.Forms.Button
    Friend WithEvents btn_studentrep As System.Windows.Forms.Button
    Friend WithEvents btn_productrep As System.Windows.Forms.Button
    Friend WithEvents btn_servicerep As System.Windows.Forms.Button
    Friend WithEvents btn_staffrep As System.Windows.Forms.Button
    Friend WithEvents btn_customerrep As System.Windows.Forms.Button
    Friend WithEvents btn_cashrep As System.Windows.Forms.Button
    Friend WithEvents btn_expencerep As System.Windows.Forms.Button
    Friend WithEvents btn_incomerep As System.Windows.Forms.Button
    Friend WithEvents btn_billrep As System.Windows.Forms.Button
    Friend WithEvents btn_bookingrep As System.Windows.Forms.Button
    Friend WithEvents btn_settings As System.Windows.Forms.Button

End Class
